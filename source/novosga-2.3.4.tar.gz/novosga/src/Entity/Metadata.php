<?php

declare(strict_types=1);

/*
 * This file is part of the NovoSGA project.
 *
 * (c) Rogerio Lino <rogeriolino@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace App\Entity;

use App\Repository\MetadataRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * System metadata.
 *
 * @author Rogerio Lino <rogeriolino@gmail.com>
 */
#[ORM\Entity(repositoryClass: MetadataRepository::class)]
#[ORM\Table(name: 'metadata')]
class Metadata extends AbstractMetadata
{
}
