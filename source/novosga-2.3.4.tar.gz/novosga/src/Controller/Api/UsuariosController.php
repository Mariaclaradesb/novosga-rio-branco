<?php

declare(strict_types=1);

/*
 * This file is part of the NovoSGA project.
 *
 * (c) Rogerio Lino <rogeriolino@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace App\Controller\Api;

use App\Entity\Usuario;
use Symfony\Component\Routing\Attribute\Route;

/**
 * @extends ApiCrudController<Usuario>
 *
 * @author Rogério Lino <rogeriolino@gmail.com>
 */
#[Route('/api/usuarios')]
class UsuariosController extends ApiCrudController
{
    use Actions\GetTrait;
    use Actions\FindTrait;

    public function getEntityName(): string
    {
        return Usuario::class;
    }

    public function getSearchableFields(): array
    {
        return ['id', 'login', 'nome', 'email'];
    }
}
